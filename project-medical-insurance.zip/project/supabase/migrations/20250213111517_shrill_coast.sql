/*
  # Implement Role-Based Access Control (RBAC)

  1. Create Roles
    - policyholder_role: For policyholders
    - insurer_role: For insurance company employees
  
  2. Grant Permissions
    - Policyholders can:
      - Read/write their own claims and family members
      - Read cities
    - Insurers can:
      - Read/write claims in their city
      - Read profiles and family members in their city
      - Read cities
*/

-- Create roles
CREATE ROLE policyholder_role NOLOGIN;
CREATE ROLE insurer_role NOLOGIN;

-- Grant basic permissions to both roles
GRANT USAGE ON SCHEMA public TO policyholder_role, insurer_role;
GRANT SELECT ON TABLE cities TO policyholder_role, insurer_role;

-- Policyholder permissions
GRANT SELECT, INSERT, UPDATE ON TABLE claims TO policyholder_role;
GRANT SELECT, INSERT, UPDATE ON TABLE family_members TO policyholder_role;
GRANT SELECT ON TABLE profiles TO policyholder_role;

-- Insurer permissions
GRANT SELECT, UPDATE ON TABLE claims TO insurer_role;
GRANT SELECT ON TABLE family_members TO insurer_role;
GRANT SELECT ON TABLE profiles TO insurer_role;

-- Create function to set role for new users
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER AS $$
DECLARE
  user_role text;
BEGIN
  -- Get the user's role from profiles table
  SELECT role INTO user_role
  FROM profiles
  WHERE id = NEW.id;

  -- Grant appropriate role
  IF user_role = 'policyholder' THEN
    EXECUTE format('GRANT policyholder_role TO %I', NEW.email);
  ELSIF user_role = 'insurer' THEN
    EXECUTE format('GRANT insurer_role TO %I', NEW.email);
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically assign roles
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_new_user();

-- Create view for insurers to see claims in their city
CREATE OR REPLACE VIEW claims_in_insurer_city AS
SELECT c.*
FROM claims c
JOIN family_members fm ON fm.id = c.family_member_id
JOIN profiles p ON p.id = fm.profile_id
WHERE p.city_id = (
  SELECT city_id 
  FROM profiles 
  WHERE id = auth.uid()
);

-- Grant access to the view
GRANT SELECT ON claims_in_insurer_city TO insurer_role;

-- Update RLS policies to work with RBAC
ALTER TABLE claims ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Policyholders can manage their claims"
  ON claims
  AS PERMISSIVE
  TO policyholder_role
  USING (
    EXISTS (
      SELECT 1 FROM family_members
      WHERE id = claims.family_member_id
      AND profile_id = auth.uid()
    )
  );

CREATE POLICY "Insurers can manage claims in their city"
  ON claims
  AS PERMISSIVE
  TO insurer_role
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN family_members fm ON fm.profile_id = p.id
      WHERE fm.id = claims.family_member_id
      AND EXISTS (
        SELECT 1 FROM profiles i
        WHERE i.id = auth.uid()
        AND i.role = 'insurer'
        AND i.city_id = p.city_id
      )
    )
  );

-- Function to handle role revocation on user deletion
CREATE OR REPLACE FUNCTION handle_user_deletion()
RETURNS TRIGGER AS $$
BEGIN
  -- Revoke roles
  EXECUTE format('REVOKE policyholder_role FROM %I', OLD.email);
  EXECUTE format('REVOKE insurer_role FROM %I', OLD.email);
  RETURN OLD;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for user deletion
CREATE TRIGGER on_auth_user_deleted
  BEFORE DELETE ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION handle_user_deletion();

-- Update the claims view to use RBAC
CREATE OR REPLACE VIEW user_claims AS
SELECT 
  c.*,
  fm.full_name as family_member_name,
  fm.relationship,
  p.city_id
FROM claims c
JOIN family_members fm ON fm.id = c.family_member_id
JOIN profiles p ON p.id = fm.profile_id
WHERE 
  (CURRENT_USER = 'authenticated' AND EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'policyholder'
    AND p.id = profiles.id
  ))
  OR
  (CURRENT_USER = 'authenticated' AND EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
    AND role = 'insurer'
    AND city_id = p.city_id
  ));

-- Grant access to the view
GRANT SELECT ON user_claims TO policyholder_role, insurer_role;