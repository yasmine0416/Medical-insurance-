/*
  # Add document URL support

  1. Changes
    - Add document_url column to claims table
    - Add document_preview_url column to claims table
    - Add check constraint for image file types
*/

-- Add new columns
ALTER TABLE claims
ADD COLUMN IF NOT EXISTS document_url text[],
ADD COLUMN IF NOT EXISTS document_preview_url text[];

-- Add check constraint for file types
ALTER TABLE claims
ADD CONSTRAINT valid_document_types 
CHECK (
  NOT EXISTS (
    SELECT unnest(documents) AS doc
    WHERE NOT (
      doc LIKE '%.jpg' OR 
      doc LIKE '%.jpeg' OR 
      doc LIKE '%.png'
    )
  )
);