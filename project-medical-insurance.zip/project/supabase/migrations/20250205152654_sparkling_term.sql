/*
  # Fix RLS policies for profiles table

  1. Changes
    - Drop existing policies for profiles table
    - Create new, optimized policies without recursion
    - Add proper documentation
*/

-- Drop existing policies for profiles table
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
DROP POLICY IF EXISTS "Insurers can view profiles in their city" ON profiles;

-- Create new policies without recursion
CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Insurers can view profiles in their city"
  ON profiles FOR SELECT
  USING (
    EXISTS (
      SELECT 1
      FROM auth.users
      WHERE auth.users.id = auth.uid()
      AND EXISTS (
        SELECT 1
        FROM profiles insurer_profile
        WHERE insurer_profile.id = auth.uid()
        AND insurer_profile.role = 'insurer'
        AND insurer_profile.city_id = profiles.city_id
      )
    )
  );

-- Add storage policies for document uploads
CREATE POLICY "Users can upload their own documents"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'documents' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Users can read their own documents"
  ON storage.objects FOR SELECT
  TO authenticated
  USING (bucket_id = 'documents' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Create documents bucket if it doesn't exist
INSERT INTO storage.buckets (id, name)
VALUES ('documents', 'documents')
ON CONFLICT (id) DO NOTHING;