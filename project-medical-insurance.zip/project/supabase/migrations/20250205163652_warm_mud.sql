/*
  # Simplify policies and add test data
  
  1. Changes
    - Drop complex policies
    - Add simple policies
    - Insert test data with actual UUIDs
*/

-- Drop existing complex policies
DROP POLICY IF EXISTS "Users can view their own profile" ON profiles;
DROP POLICY IF EXISTS "Insurers can view profiles in their city" ON profiles;
DROP POLICY IF EXISTS "Insurers view city profiles" ON profiles;

-- Create simple policies
CREATE POLICY "Enable read access for authenticated users"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Enable update for users based on id"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);

-- Insert test data for cities (if not exists)
INSERT INTO cities (id, name)
SELECT 
  '11111111-1111-1111-1111-111111111111',
  'New York'
WHERE NOT EXISTS (
  SELECT 1 FROM cities WHERE id = '11111111-1111-1111-1111-111111111111'
);

-- Create test users and profiles
DO $$
DECLARE
  policyholder_id uuid;
  insurer_id uuid;
  family_member_id uuid;
BEGIN
  -- Create policyholder test account
  INSERT INTO auth.users (id, email)
  VALUES (
    '22222222-2222-2222-2222-222222222222',
    'test.policyholder@example.com'
  ) ON CONFLICT (id) DO NOTHING
  RETURNING id INTO policyholder_id;

  -- Create insurer test account
  INSERT INTO auth.users (id, email)
  VALUES (
    '33333333-3333-3333-3333-333333333333',
    'test.insurer@example.com'
  ) ON CONFLICT (id) DO NOTHING
  RETURNING id INTO insurer_id;

  -- Create profiles for test users
  INSERT INTO profiles (id, full_name, role, city_id)
  VALUES
    (
      '22222222-2222-2222-2222-222222222222',
      'John Policyholder',
      'policyholder',
      '11111111-1111-1111-1111-111111111111'
    ),
    (
      '33333333-3333-3333-3333-333333333333',
      'Jane Insurer',
      'insurer',
      '11111111-1111-1111-1111-111111111111'
    )
  ON CONFLICT (id) DO NOTHING;

  -- Create family members for policyholder
  INSERT INTO family_members (id, profile_id, full_name, relationship, date_of_birth)
  VALUES 
    (
      '44444444-4444-4444-4444-444444444444',
      '22222222-2222-2222-2222-222222222222',
      'John Policyholder',
      'self',
      '1990-01-01'
    ),
    (
      '55555555-5555-5555-5555-555555555555',
      '22222222-2222-2222-2222-222222222222',
      'Mary Policyholder',
      'spouse',
      '1992-01-01'
    )
  ON CONFLICT (id) DO NOTHING;

  -- Create test claims
  INSERT INTO claims (
    id,
    family_member_id,
    date,
    amount,
    provider_name,
    service_type,
    status,
    documents
  )
  VALUES 
    (
      '66666666-6666-6666-6666-666666666666',
      '44444444-4444-4444-4444-444444444444',
      '2024-02-01',
      500.00,
      'City Hospital',
      'Consultation',
      'pending',
      ARRAY[]::text[]
    ),
    (
      '77777777-7777-7777-7777-777777777777',
      '44444444-4444-4444-4444-444444444444',
      '2024-02-05',
      1200.00,
      'Dental Clinic',
      'Root Canal',
      'pending',
      ARRAY[]::text[]
    )
  ON CONFLICT (id) DO NOTHING;
END $$;