/*
  # Add test data

  1. Test Data
    - Add initial cities
    - Add test profiles for policyholder and insurer
    - Add family members for policyholder
    - Add sample claims
*/

-- Insert test cities
INSERT INTO cities (id, name) VALUES
  ('11111111-1111-1111-1111-111111111111', 'New York'),
  ('22222222-2222-2222-2222-222222222222', 'Los Angeles'),
  ('33333333-3333-3333-3333-333333333333', 'Chicago');

-- Note: The following comments are for reference. Actual user profiles will be created
-- through the application's signup process using Supabase Auth.

/*
Test accounts for the application:

1. Policyholder Account:
   - Email: test.policyholder@example.com
   - Password: Test123!@#
   - Will be assigned to New York

2. Insurer Account:
   - Email: test.insurer@example.com
   - Password: Test123!@#
   - Will be assigned to New York
*/

-- Create a function to help insert test data after user signup
CREATE OR REPLACE FUNCTION create_test_data_for_user()
RETURNS TRIGGER AS $$
DECLARE
  new_york_id uuid := '11111111-1111-1111-1111-111111111111';
BEGIN
  -- Add test family members for policyholder
  IF NEW.role = 'policyholder' THEN
    INSERT INTO family_members (profile_id, full_name, relationship, date_of_birth)
    VALUES
      (NEW.id, NEW.full_name, 'self', CURRENT_DATE - INTERVAL '30 years'),
      (NEW.id, 'Jane Doe', 'spouse', CURRENT_DATE - INTERVAL '28 years'),
      (NEW.id, 'Billy Doe', 'child', CURRENT_DATE - INTERVAL '5 years');
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger to automatically add test data for new users
CREATE TRIGGER add_test_data_after_profile_insert
  AFTER INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION create_test_data_for_user();

-- Enable RLS for the new function
ALTER FUNCTION create_test_data_for_user() SECURITY DEFINER;