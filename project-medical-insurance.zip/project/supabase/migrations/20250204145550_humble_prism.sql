/*
  # Medical Insurance Claims System Schema

  1. New Tables
    - `profiles`
      - Extends default auth.users
      - Stores additional user information
      - Links to role and city information
    
    - `family_members`
      - Stores family member information
      - Links to policyholder profile
    
    - `claims`
      - Stores claim information
      - Links to family member and insurer
    
    - `cities`
      - Stores city information
      - Used for insurer assignment

  2. Security
    - Enable RLS on all tables
    - Policies for policyholders and insurers
    - Secure access control based on roles

  3. Enums and Types
    - claim_status
    - relationship_type
    - user_role
*/

-- Create custom types
CREATE TYPE user_role AS ENUM ('policyholder', 'insurer');
CREATE TYPE claim_status AS ENUM ('pending', 'approved', 'rejected');
CREATE TYPE relationship_type AS ENUM ('self', 'spouse', 'child', 'parent');

-- Create cities table
CREATE TABLE cities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  created_at timestamptz DEFAULT now()
);

-- Create profiles table extending auth.users
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  full_name text NOT NULL,
  role user_role NOT NULL DEFAULT 'policyholder',
  city_id uuid REFERENCES cities(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create family_members table
CREATE TABLE family_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid REFERENCES profiles(id) NOT NULL,
  full_name text NOT NULL,
  relationship relationship_type NOT NULL,
  date_of_birth date NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create claims table
CREATE TABLE claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  family_member_id uuid REFERENCES family_members(id) NOT NULL,
  insurer_id uuid REFERENCES profiles(id),
  date date NOT NULL,
  amount decimal(10,2) NOT NULL,
  provider_name text NOT NULL,
  service_type text NOT NULL,
  status claim_status DEFAULT 'pending',
  documents text[] NOT NULL,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE family_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE claims ENABLE ROW LEVEL SECURITY;
ALTER TABLE cities ENABLE ROW LEVEL SECURITY;

-- Policies for profiles
CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Insurers can view profiles in their city"
  ON profiles FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'insurer'
      AND city_id = profiles.city_id
    )
  );

-- Policies for family_members
CREATE POLICY "Users can manage their family members"
  ON family_members FOR ALL
  USING (profile_id = auth.uid());

CREATE POLICY "Insurers can view family members in their city"
  ON family_members FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      WHERE p.id = family_members.profile_id
      AND EXISTS (
        SELECT 1 FROM profiles i
        WHERE i.id = auth.uid()
        AND i.role = 'insurer'
        AND i.city_id = p.city_id
      )
    )
  );

-- Policies for claims
CREATE POLICY "Users can manage their claims"
  ON claims FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM family_members
      WHERE id = claims.family_member_id
      AND profile_id = auth.uid()
    )
  );

CREATE POLICY "Insurers can manage claims in their city"
  ON claims FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles p
      JOIN family_members fm ON fm.profile_id = p.id
      WHERE fm.id = claims.family_member_id
      AND EXISTS (
        SELECT 1 FROM profiles i
        WHERE i.id = auth.uid()
        AND i.role = 'insurer'
        AND i.city_id = p.city_id
      )
    )
  );

-- Policies for cities
CREATE POLICY "Cities are readable by all authenticated users"
  ON cities FOR SELECT
  TO authenticated
  USING (true);

-- Functions for claim limits
CREATE OR REPLACE FUNCTION check_claim_limit(profile_id uuid)
RETURNS boolean AS $$
DECLARE
  claim_count int;
BEGIN
  SELECT COUNT(*)
  INTO claim_count
  FROM claims c
  JOIN family_members fm ON fm.id = c.family_member_id
  WHERE fm.profile_id = $1
  AND c.created_at > now() - interval '3 months'
  AND c.status != 'rejected';
  
  RETURN claim_count < 3;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;