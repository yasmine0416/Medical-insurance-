/*
  # Add Claim Limit Trigger

  1. Changes
    - Add trigger to enforce claim limits (3 approved claims per 3 months)
    - Trigger applies to both policyholder and family members
    - Counts only approved claims
*/

-- Create function to check claim limits
CREATE OR REPLACE FUNCTION check_claim_limit()
RETURNS TRIGGER AS $$
DECLARE
  approved_claims INTEGER;
BEGIN
  -- Count approved claims in last 3 months for the policyholder and their family
  SELECT COUNT(*) INTO approved_claims
  FROM claims c
  JOIN family_members fm ON fm.id = c.family_member_id
  WHERE fm.profile_id = (
    SELECT profile_id 
    FROM family_members 
    WHERE id = NEW.family_member_id
  )
  AND c.status = 'approved'
  AND c.created_at > NOW() - INTERVAL '3 months';

  IF approved_claims >= 3 THEN
    RAISE EXCEPTION 'Claim limit exceeded: Maximum 3 approved claims allowed in a 3-month period';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger
DROP TRIGGER IF EXISTS enforce_claim_limit ON claims;
CREATE TRIGGER enforce_claim_limit
  BEFORE INSERT ON claims
  FOR EACH ROW
  EXECUTE FUNCTION check_claim_limit();