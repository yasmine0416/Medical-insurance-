/*
  # Add document text storage for claims

  1. Changes
    - Add document_text column to claims table to store extracted text
    - Add family_member_name column for denormalized access
*/

ALTER TABLE claims 
ADD COLUMN IF NOT EXISTS document_text text[],
ADD COLUMN IF NOT EXISTS family_member_name text;