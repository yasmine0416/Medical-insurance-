/*
  # Add rejection reason to claims

  1. Changes
    - Add rejection_reason column to claims table
    - Update existing claims to have null rejection_reason
*/

-- Add rejection_reason column to claims table
ALTER TABLE claims 
ADD COLUMN IF NOT EXISTS rejection_reason text;