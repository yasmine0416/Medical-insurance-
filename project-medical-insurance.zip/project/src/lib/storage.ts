import { supabase } from './supabase';

const BUCKET_NAME = 'documents';

export async function uploadClaimDocument(file: File, claimId: string): Promise<string> {
  try {
    // Generate unique file path
    const fileExt = file.name.split('.').pop();
    const fileName = `${claimId}/${Math.random().toString(36).slice(2)}.${fileExt}`;
    const filePath = `claims/${fileName}`;

    // Upload file to Supabase storage
    const { error: uploadError } = await supabase.storage
      .from(BUCKET_NAME)
      .upload(filePath, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) {
      throw uploadError;
    }

    // Get public URL for the uploaded file
    const { data: { publicUrl } } = supabase.storage
      .from(BUCKET_NAME)
      .getPublicUrl(filePath);

    return publicUrl;
  } catch (error) {
    console.error('Error uploading document:', error);
    throw error;
  }
}

export async function uploadClaimDocuments(files: File[], claimId: string): Promise<string[]> {
  const uploadPromises = files.map(file => uploadClaimDocument(file, claimId));
  return Promise.all(uploadPromises);
}