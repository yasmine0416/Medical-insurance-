import * as pdfjsLib from 'pdfjs-dist';
import Tesseract from 'tesseract.js';
import imageCompression from 'browser-image-compression';

// Configure PDF.js worker with a more reliable CDN
const PDFJS_CDN = 'https://unpkg.com/pdfjs-dist@4.0.379/build/pdf.worker.min.js';
pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_CDN;

const MAX_PDF_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB

export async function extractTextFromPDF(file: File): Promise<string> {
  try {
    if (file.size > MAX_PDF_SIZE) {
      throw new Error('PDF file size exceeds 10MB limit');
    }

    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';

    // Extract text from all pages
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n';
    }

    return fullText.trim() || 'No text could be extracted from the PDF';
  } catch (error) {
    console.error('Error extracting text from PDF:', error);
    throw new Error(`Failed to extract text from PDF: ${error.message}`);
  }
}

export async function extractTextFromImage(file: File): Promise<string> {
  try {
    if (file.size > MAX_IMAGE_SIZE) {
      throw new Error('Image file size exceeds 5MB limit');
    }

    // Compress image before processing
    const compressedFile = await imageCompression(file, {
      maxSizeMB: 1,
      maxWidthOrHeight: 1920,
      useWebWorker: true
    });

    // Perform OCR
    const result = await Tesseract.recognize(
      compressedFile,
      'eng',
      {
        logger: m => console.log(m)
      }
    );

    return result.data.text.trim() || 'No text could be extracted from the image';
  } catch (error) {
    console.error('Error extracting text from image:', error);
    throw new Error(`Failed to extract text from image: ${error.message}`);
  }
}

export async function processDocument(file: File): Promise<string> {
  try {
    if (!file) {
      throw new Error('No file provided');
    }

    // Validate file type
    if (!['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)) {
      throw new Error('Unsupported file type. Please upload PDF, JPG, or PNG files.');
    }

    // Extract text based on file type
    const extractedText = file.type === 'application/pdf'
      ? await extractTextFromPDF(file)
      : await extractTextFromImage(file);

    if (!extractedText) {
      throw new Error('No text could be extracted from the document');
    }

    return extractedText;
  } catch (error) {
    console.error('Error processing document:', error);
    throw error;
  }
}

export async function processMultipleDocuments(files: File[]): Promise<string[]> {
  try {
    const results = await Promise.all(files.map(file => processDocument(file)));
    return results;
  } catch (error) {
    console.error('Error processing multiple documents:', error);
    throw error;
  }
}