export function validatePassword(password: string): string[] {
  const errors: string[] = [];
  
  if (password.length < 8) {
    errors.push('Password must be at least 8 characters long');
  }
  if (!/[A-Z]/.test(password)) {
    errors.push('Password must contain at least one uppercase letter');
  }
  if (!/[a-z]/.test(password)) {
    errors.push('Password must contain at least one lowercase letter');
  }
  if (!/[0-9]/.test(password)) {
    errors.push('Password must contain at least one number');
  }
  if (!/[!@#$%^&*]/.test(password)) {
    errors.push('Password must contain at least one special character (!@#$%^&*)');
  }

  return errors;
}

export function sanitizeInput(input: string): string {
  return input
    .trim()
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/['"]/g, '') // Remove quotes
    .replace(/[;]/g, ''); // Remove semicolons
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validateFullName(name: string): boolean {
  return name.trim().length >= 2 && /^[a-zA-Z\s'-]+$/.test(name);
}

export interface DocumentValidationResult {
  isValid: boolean;
  errors: string[];
  extractedData?: {
    policyDetails?: string;
    coverageInfo?: string;
    dates?: string[];
    personalInfo?: string;
    financialData?: string;
  };
}

export async function validateDocument(file: File): Promise<DocumentValidationResult> {
  const errors: string[] = [];
  const maxSize = file.type === 'application/pdf' ? 10 * 1024 * 1024 : 5 * 1024 * 1024;
  
  if (file.size > maxSize) {
    errors.push(`File size exceeds the maximum limit of ${maxSize / (1024 * 1024)}MB`);
  }

  if (!['application/pdf', 'image/jpeg', 'image/png'].includes(file.type)) {
    errors.push('Invalid file type. Only PDF, JPG, and PNG files are supported');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}