import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import LandingPage from '../pages/LandingPage';
import LoginPage from '../pages/LoginPage';
import SignUpPage from '../pages/SignUpPage';
import DashboardLayout from '../components/layouts/DashboardLayout';
import PolicyholderDashboard from '../pages/policyholder/Dashboard';
import FamilyMembers from '../pages/policyholder/FamilyMembers';
import Claims from '../pages/policyholder/Claims';
import NewClaim from '../pages/policyholder/NewClaim';
import InsurerDashboard from '../pages/insurer/Dashboard';
import ClaimsReview from '../pages/insurer/ClaimsReview';
import Analytics from '../pages/insurer/Analytics';

function LoadingSpinner() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
    </div>
  );
}

function PrivateRoute({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  return <>{children}</>;
}

function RoleRoute({ children, allowedRole }: { children: React.ReactNode; allowedRole: string }) {
  const { profile, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingSpinner />;
  }

  if (!profile) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  if (profile.role !== allowedRole) {
    return <Navigate to="/dashboard" replace />;
  }

  return <>{children}</>;
}

export default function AppRoutes() {
  const { user, profile, loading } = useAuth();

  // Show loading spinner while checking initial auth state
  if (loading) {
    return <LoadingSpinner />;
  }

  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={!user ? <LandingPage /> : <Navigate to="/dashboard" replace />} />
      <Route path="/login" element={!user ? <LoginPage /> : <Navigate to="/dashboard" replace />} />
      <Route path="/signup" element={!user ? <SignUpPage /> : <Navigate to="/dashboard" replace />} />

      {/* Protected routes */}
      <Route path="/dashboard" element={
        <PrivateRoute>
          <DashboardLayout>
            {profile?.role === 'policyholder' ? <PolicyholderDashboard /> : <InsurerDashboard />}
          </DashboardLayout>
        </PrivateRoute>
      } />

      {/* Policyholder routes */}
      <Route path="/family-members" element={
        <PrivateRoute>
          <RoleRoute allowedRole="policyholder">
            <DashboardLayout>
              <FamilyMembers />
            </DashboardLayout>
          </RoleRoute>
        </PrivateRoute>
      } />
      <Route path="/claims" element={
        <PrivateRoute>
          <RoleRoute allowedRole="policyholder">
            <DashboardLayout>
              <Claims />
            </DashboardLayout>
          </RoleRoute>
        </PrivateRoute>
      } />
      <Route path="/claims/new" element={
        <PrivateRoute>
          <RoleRoute allowedRole="policyholder">
            <DashboardLayout>
              <NewClaim />
            </DashboardLayout>
          </RoleRoute>
        </PrivateRoute>
      } />

      {/* Insurer routes */}
      <Route path="/claims-review" element={
        <PrivateRoute>
          <RoleRoute allowedRole="insurer">
            <DashboardLayout>
              <ClaimsReview />
            </DashboardLayout>
          </RoleRoute>
        </PrivateRoute>
      } />
      <Route path="/analytics" element={
        <PrivateRoute>
          <RoleRoute allowedRole="insurer">
            <DashboardLayout>
              <Analytics />
            </DashboardLayout>
          </RoleRoute>
        </PrivateRoute>
      } />

      {/* Catch all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}