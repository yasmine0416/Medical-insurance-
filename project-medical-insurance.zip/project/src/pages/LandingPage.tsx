import { Link } from 'react-router-dom';
import { Shield } from 'lucide-react';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-16">
        <div className="flex flex-col items-center text-center">
          <Shield className="w-16 h-16 text-blue-600 mb-8" />
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Medical Insurance Claims Management
          </h1>
          <p className="text-xl text-gray-600 mb-12 max-w-2xl">
            Streamline your medical insurance claims process with our secure and user-friendly platform.
          </p>
          <div className="flex gap-4">
            <Link
              to="/login"
              className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              Sign In
            </Link>
{/*
  <Link
    to="/signup"
    className="px-8 py-3 bg-white text-blue-600 border border-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
  >
    Create Account
  </Link>
*/}


          </div>
        </div>

        <div className="mt-24 grid md:grid-cols-3 gap-8">
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-semibold mb-4">For Policyholders</h3>
            <ul className="space-y-2 text-gray-600">
              <li>✓ Easy claim submission</li>
              <li>✓ Track claim status</li>
              <li>✓ Manage family members</li>
              <li>✓ Secure document upload</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-semibold mb-4">For Insurers</h3>
            <ul className="space-y-2 text-gray-600">
              <li>✓ Efficient claim review</li>
              <li>✓ City-based assignment</li>
              <li>✓ Analytics dashboard</li>
              <li>✓ Secure communication</li>
            </ul>
          </div>
          <div className="bg-white p-6 rounded-xl shadow-sm">
            <h3 className="text-xl font-semibold mb-4">Security & Privacy</h3>
            <ul className="space-y-2 text-gray-600">
              <li>✓ End-to-end encryption</li>
              <li>✓ Role-based access</li>
              <li>✓ Data protection</li>
              <li>✓ Secure storage</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}