import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { BarChart2, TrendingUp, DollarSign } from 'lucide-react';

export default function Analytics() {
  const { profile } = useAuth();
  const [stats, setStats] = useState({
    totalClaims: 0,
    totalAmount: 0,
    avgProcessingTime: 0,
    approvalRate: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchAnalytics() {
      if (!profile?.city_id) return;

      const { data: claims, error } = await supabase
        .from('claims')
        .select(`
          *,
          family_members (
            profiles (city_id)
          )
        `)
        .eq('family_members.profiles.city_id', profile.city_id);

      if (error) {
        console.error('Error fetching analytics:', error);
        return;
      }

      const totalClaims = claims.length;
      const totalAmount = claims.reduce((sum, claim) => sum + claim.amount, 0);
      const approvedClaims = claims.filter(claim => claim.status === 'approved').length;
      const approvalRate = totalClaims > 0 ? (approvedClaims / totalClaims) * 100 : 0;

      setStats({
        totalClaims,
        totalAmount,
        avgProcessingTime: 3.5, // Placeholder - would need actual timestamps
        approvalRate,
      });

      setLoading(false);
    }

    fetchAnalytics();
  }, [profile]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Analytics Dashboard</h1>

      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <BarChart2 className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Claims
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.totalClaims}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <DollarSign className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Amount
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      DA{stats.totalAmount.toFixed(2)}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <TrendingUp className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Approval Rate
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {stats.approvalRate.toFixed(1)}%
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}