import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Claim } from '../../types/database';
import { FileText, Download, AlertCircle, ChevronDown, ChevronUp, Search, Calendar, Filter } from 'lucide-react';
import toast from 'react-hot-toast';
import { format, parseISO } from 'date-fns';

export default function ClaimsReview() {
  const { profile } = useAuth();
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const [rejectionReason, setRejectionReason] = useState('');
  const [selectedClaimId, setSelectedClaimId] = useState<string | null>(null);
  const [expandedClaims, setExpandedClaims] = useState<Set<string>>(new Set());
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    search: '',
    serviceType: '',
    status: 'pending'
  });

  useEffect(() => {
    async function fetchClaims() {
      if (!profile?.city_id) return;

      let query = supabase
        .from('claims')
        .select(`
          *,
          family_members (
            *,
            profiles (*)
          )
        `)
        .eq('family_members.profiles.city_id', profile.city_id)
        .order('created_at', { ascending: false });

      // Apply filters
      if (filters.status) {
        query = query.eq('status', filters.status);
      }
      if (filters.startDate) {
        query = query.gte('date', filters.startDate);
      }
      if (filters.endDate) {
        query = query.lte('date', filters.endDate);
      }
      if (filters.search) {
        query = query.or(`provider_name.ilike.%${filters.search}%,service_type.ilike.%${filters.search}%,family_member_name.ilike.%${filters.search}%`);
      }
      if (filters.serviceType) {
        query = query.eq('service_type', filters.serviceType);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching claims:', error);
        return;
      }

      setClaims(data);
      setLoading(false);
    }

    fetchClaims();
  }, [profile, filters]);

  async function handleClaimAction(claimId: string, action: 'approved' | 'rejected') {
    try {
      if (action === 'rejected' && !rejectionReason) {
        toast.error('Please provide a reason for rejection');
        return;
      }

      const { error } = await supabase
        .from('claims')
        .update({ 
          status: action, 
          insurer_id: profile?.id,
          rejection_reason: action === 'rejected' ? rejectionReason : null
        })
        .eq('id', claimId);

      if (error) throw error;

      setClaims(claims.filter(claim => claim.id !== claimId));
      setRejectionReason('');
      setSelectedClaimId(null);
      toast.success(`Claim ${action} successfully`);
    } catch (error) {
      toast.error('Failed to update claim Family member has more than 3 approved claims in this quarter. Cannot approve more claims. ');
      console.error('Error updating claim:', error);
    }
  }

  function toggleClaimExpansion(claimId: string) {
    setExpandedClaims(prev => {
      const newSet = new Set(prev);
      if (newSet.has(claimId)) {
        newSet.delete(claimId);
      } else {
        newSet.add(claimId);
      }
      return newSet;
    });
  }

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Claims Review</h1>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Start Date</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => setFilters(f => ({ ...f, startDate: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">End Date</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => setFilters(f => ({ ...f, endDate: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Search</label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <input
                type="text"
                value={filters.search}
                onChange={(e) => setFilters(f => ({ ...f, search: e.target.value }))}
                placeholder="Provider, service, or member..."
                className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Service Type</label>
            <select
              value={filters.serviceType}
              onChange={(e) => setFilters(f => ({ ...f, serviceType: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            >
              <option value="">All Services</option>
              {Array.from(new Set(claims.map(c => c.service_type))).map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Status</label>
            <select
              value={filters.status}
              onChange={(e) => setFilters(f => ({ ...f, status: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            >
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
              <option value="">All Status</option>
            </select>
          </div>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {claims.map((claim) => (
            <li key={claim.id}>
              <div className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <p className="text-lg font-medium text-gray-900">
                        {claim.provider_name}
                      </p>
                      <button
                        onClick={() => toggleClaimExpansion(claim.id)}
                        className="ml-2 text-gray-400 hover:text-gray-500"
                      >
                        {expandedClaims.has(claim.id) ? (
                          <ChevronUp className="h-5 w-5" />
                        ) : (
                          <ChevronDown className="h-5 w-5" />
                        )}
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Family Member:</span>{' '}
                          {claim.family_member_name}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Relationship:</span>{' '}
                          {claim.family_members?.relationship}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Service Type:</span>{' '}
                          {claim.service_type}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Amount:</span> DA{claim.amount}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Date:</span>{' '}
                          {format(parseISO(claim.date), 'MMM dd, yyyy')}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Submitted:</span>{' '}
                          {format(parseISO(claim.created_at), 'MMM dd, yyyy')}
                        </p>
                      </div>
                    </div>
                    
                    {expandedClaims.has(claim.id) && (
                      <div className="mt-4 space-y-4">
                        <div className="bg-gray-50 p-4 rounded-md">
                          <h4 className="text-sm font-medium text-gray-900 mb-2">
                            Extracted Document Text
                          </h4>
                          {claim.document_text && claim.document_text.length > 0 ? (
                            <div className="space-y-2">
                              {claim.document_text.map((text, index) => (
                                <div key={index} className="bg-white p-3 rounded border border-gray-200">
                                  <p className="text-sm text-gray-600 whitespace-pre-wrap">
                                    {text}
                                  </p>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <p className="text-sm text-gray-500">No document text available</p>
                          )}
                        </div>

                        <div className="bg-gray-50 p-4 rounded-md">
                          <h4 className="text-sm font-medium text-gray-900 mb-2">
                            Service Details
                          </h4>
                          <dl className="grid grid-cols-1 gap-x-4 gap-y-2 sm:grid-cols-2">
                            <div>
                              <dt className="text-sm font-medium text-gray-500">Service Type</dt>
                              <dd className="text-sm text-gray-900">{claim.service_type}</dd>
                            </div>
                            <div>
                              <dt className="text-sm font-medium text-gray-500">Provider</dt>
                              <dd className="text-sm text-gray-900">{claim.provider_name}</dd>
                            </div>
                            <div>
                              <dt className="text-sm font-medium text-gray-500">Submission Date</dt>
                              <dd className="text-sm text-gray-900">
                                {format(parseISO(claim.created_at), 'MMM dd, yyyy')}
                              </dd>
                            </div>
                            {claim.notes && (
                              <div className="col-span-2">
                                <dt className="text-sm font-medium text-gray-500">Additional Notes</dt>
                                <dd className="text-sm text-gray-900">{claim.notes}</dd>
                              </div>
                            )}
                          </dl>
                        </div>
                      </div>
                    )}
                  </div>

                  {claim.status === 'pending' && (
                    <div className="flex flex-col space-y-2">
                      <button
                        onClick={() => handleClaimAction(claim.id, 'approved')}
                        className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700"
                      >
                        Approve
                      </button>
                      <button
                        onClick={() => setSelectedClaimId(claim.id)}
                        className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>

                {/* Rejection reason modal */}
                {selectedClaimId === claim.id && (
                  <div className="mt-4 p-4 bg-gray-50 rounded-md">
                    <label htmlFor="rejectionReason" className="block text-sm font-medium text-gray-700">
                      Rejection Reason
                    </label>
                    <textarea
                      id="rejectionReason"
                      rows={3}
                      className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
                      value={rejectionReason}
                      onChange={(e) => setRejectionReason(e.target.value)}
                      placeholder="Please provide a reason for rejection..."
                    />
                    <div className="mt-3 flex justify-end space-x-3">
                      <button
                        onClick={() => {
                          setSelectedClaimId(null);
                          setRejectionReason('');
                        }}
                        className="inline-flex items-center px-3 py-1 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleClaimAction(claim.id, 'rejected')}
                        className="inline-flex items-center px-3 py-1 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
                      >
                        Confirm Rejection
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}