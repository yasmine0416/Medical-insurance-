import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Upload, X, AlertCircle, Eye, FileText } from 'lucide-react';
import { processDocument } from '../../lib/documentProcessing';
import toast from 'react-hot-toast';
import { FamilyMember } from '../../types/database';
import { format, subDays } from 'date-fns';

const MAX_PDF_SIZE = 10 * 1024 * 1024; // 10MB
const MAX_IMAGE_SIZE = 5 * 1024 * 1024; // 5MB
const ALLOWED_TYPES = {
  'application/pdf': MAX_PDF_SIZE,
  'image/jpeg': MAX_IMAGE_SIZE,
  'image/png': MAX_IMAGE_SIZE,
};

interface DocumentPreview {
  file: File;
  preview: string;
  extractedText: string;
}

export default function NewClaim() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [formData, setFormData] = useState({
    familyMemberId: '',
    providerName: '',
    serviceType: '',
    amount: '',
    date: '',
    notes: '',
  });
  const [documents, setDocuments] = useState<DocumentPreview[]>([]);
  const [processingFiles, setProcessingFiles] = useState(false);
  const [previewText, setPreviewText] = useState<string | null>(null);

  // Calculate date constraints
  const maxDate = format(new Date(), 'yyyy-MM-dd');
  const minDate = format(subDays(new Date(), 60), 'yyyy-MM-dd');

  useEffect(() => {
    async function fetchFamilyMembers() {
      if (!profile) return;
      const { data, error } = await supabase
        .from('family_members')
        .select('*')
        .eq('profile_id', profile.id);
      if (error) {
        console.error('Error fetching family members:', error);
        toast.error('Failed to load family members');
        return;
      }
      setFamilyMembers(data || []);
    }
    fetchFamilyMembers();
  }, [profile]);

  // Function to create image preview URL
  function createPreviewUrl(file: File): Promise<string> {
    return new Promise((resolve) => {
      if (file.type === 'application/pdf') {
        resolve('/pdf-icon.png'); // Use a default PDF icon
      } else {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result as string);
        reader.readAsDataURL(file);
      }
    });
  }

  async function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files || []);
    setProcessingFiles(true);
    
    try {
      // Validate files
      const validFiles = files.filter(file => {
        const maxSize = ALLOWED_TYPES[file.type as keyof typeof ALLOWED_TYPES];
        if (!maxSize) {
          toast.error(`${file.name} is not a supported file type`);
          return false;
        }
        if (file.size > maxSize) {
          toast.error(`${file.name} exceeds size limit`);
          return false;
        }
        return true;
      });

      if (validFiles.length === 0) {
        return;
      }

      // Process each file
      const newDocuments = await Promise.all(validFiles.map(async file => {
        try {
          const text = await processDocument(file);
          const preview = await createPreviewUrl(file);
          toast.success(`Successfully processed ${file.name}`);
          return {
            file,
            preview,
            extractedText: text
          };
        } catch (error) {
          toast.error(`Failed to process ${file.name}`);
          console.error(`Error processing ${file.name}:`, error);
          return null;
        }
      }));

      // Filter out failed documents and update state
      const validDocuments = newDocuments.filter((doc): doc is DocumentPreview => doc !== null);
      setDocuments(prev => [...prev, ...validDocuments]);
    } catch (error) {
      console.error('Error processing files:', error);
      toast.error('Error processing files');
    } finally {
      setProcessingFiles(false);
    }
  }

  function handleRemoveDocument(index: number) {
    setDocuments(prev => prev.filter((_, i) => i !== index));
  }

  function toggleTextPreview(text: string) {
    setPreviewText(prev => prev ? null : text);
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!formData.familyMemberId) {
      toast.error('Please select a family member');
      return;
    }
    if (!formData.date) {
      toast.error('Please select a service date');
      return;
    }
    if (documents.length === 0) {
      toast.error('Please upload at least one document');
      return;
    }

    setLoading(true);
    try {
      // Get family member name
      const familyMember = familyMembers.find(fm => fm.id === formData.familyMemberId);
      if (!familyMember) throw new Error('Family member not found');

      // Create the claim with extracted text
      const { data: claim, error: claimError } = await supabase
        .from('claims')
        .insert([
          {
            family_member_id: formData.familyMemberId,
            family_member_name: familyMember.full_name,
            provider_name: formData.providerName,
            service_type: formData.serviceType,
            amount: parseFloat(formData.amount),
            date: formData.date,
            notes: formData.notes,
            status: 'pending',
            documents: [], // Empty array to satisfy not-null constraint
            document_text: documents.map(doc => doc.extractedText) // Store extracted text directly
          }
        ])
        .select()
        .single();

      if (claimError) throw claimError;

      toast.success('Claim submitted successfully');
      navigate('/claims');
    } catch (error) {
      console.error('Error submitting claim:', error);
      toast.error('Failed to submit claim Family member has more than 3 approved claims in this quarter ');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Submit New Claim</h1>
      <div className="bg-white shadow sm:rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Family Member Selection */}
            <div>
              <label htmlFor="familyMemberId" className="block text-sm font-medium text-gray-700">
                Family Member
              </label>
              <select
                id="familyMemberId"
                value={formData.familyMemberId}
                onChange={(e) => setFormData({ ...formData, familyMemberId: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              >
                <option value="">Select a family member</option>
                {familyMembers.map((member) => (
                  <option key={member.id} value={member.id}>
                    {member.full_name} ({member.relationship})
                  </option>
                ))}
              </select>
            </div>

            {/* Provider Name */}
            <div>
              <label htmlFor="providerName" className="block text-sm font-medium text-gray-700">
                Provider Name
              </label>
              <input
                type="text"
                id="providerName"
                value={formData.providerName}
                onChange={(e) => setFormData({ ...formData, providerName: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
            </div>

            {/* Service Type */}
            <div>
              <label htmlFor="serviceType" className="block text-sm font-medium text-gray-700">
                Service Type
              </label>
              <input
                type="text"
                id="serviceType"
                value={formData.serviceType}
                onChange={(e) => setFormData({ ...formData, serviceType: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
            </div>

            {/* Amount */}
            <div>
              <label htmlFor="amount" className="block text-sm font-medium text-gray-700">
                Amount
              </label>
              <div className="mt-1 relative rounded-md shadow-sm">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-gray-500 sm:text-sm">DA</span>
                </div>
                <input
                  type="number"
                  id="amount"
                  min="0"
                  step="0.01"
                  value={formData.amount}
                  onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                  className="pl-7 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  required
                />
              </div>
            </div>

            {/* Date of Service */}
            <div>
              <label htmlFor="date" className="block text-sm font-medium text-gray-700">
                Date of Service
              </label>
              <input
                type="date"
                id="date"
                value={formData.date}
                onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
                min={minDate}
                max={maxDate}
              />
              <p className="mt-1 text-sm text-gray-500">Must be within the last 60 days</p>
            </div>

            {/* Document Upload */}
            <div>
              <label className="block text-sm font-medium text-gray-700">
                Documents
              </label>
              <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
                <div className="space-y-1 text-center">
                  <Upload className="mx-auto h-12 w-12 text-gray-400" />
                  <div className="flex text-sm text-gray-600">
                    <label
                      htmlFor="documents"
                      className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500"
                    >
                      <span>Upload files</span>
                      <input
                        id="documents"
                        name="documents"
                        type="file"
                        multiple
                        accept=".jpg,.jpeg,.png"
                        className="sr-only"
                        onChange={handleFileChange}
                        disabled={processingFiles}
                      />
                    </label>
                    <p className="pl-1">or drag and drop</p>
                  </div>
                  <p className="text-xs text-gray-500">
                     Images (max 5MB)
                  </p>
                </div>
              </div>

              {/* Document Previews */}
              {documents.length > 0 && (
                <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {documents.map((doc, index) => (
                    <div key={index} className="relative">
                      <div className="group aspect-w-10 aspect-h-7 block w-full overflow-hidden rounded-lg bg-gray-100">
                        {doc.file.type.startsWith('image/') ? (
                          <img
                            src={doc.preview}
                            alt={doc.file.name}
                            className="object-cover pointer-events-none"
                          />
                        ) : (
                          <div className="flex items-center justify-center h-full">
                            <FileText className="h-12 w-12 text-gray-400" />
                          </div>
                        )}
                        <button
                          type="button"
                          className="absolute top-2 right-2 p-1.5 rounded-full bg-red-100 text-red-600 hover:bg-red-200"
                          onClick={() => handleRemoveDocument(index)}
                        >
                          <X className="h-4 w-4" />
                        </button>
                        <button
                          type="button"
                          className="absolute bottom-2 right-2 p-1.5 rounded-full bg-blue-100 text-blue-600 hover:bg-blue-200"
                          onClick={() => toggleTextPreview(doc.extractedText)}
                        >
                          <Eye className="h-4 w-4" />
                        </button>
                      </div>
                      <p className="mt-2 block text-sm font-medium text-gray-900 truncate pointer-events-none">
                        {doc.file.name}
                      </p>
                    </div>
                  ))}
                </div>
              )}

              {/* Text Preview Modal */}
              {previewText && (
                <div className="fixed inset-0 z-10 overflow-y-auto">
                  <div className="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
                    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" onClick={() => setPreviewText(null)} />
                    <div className="inline-block align-bottom bg-white rounded-lg px-4 pt-5 pb-4 text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full sm:p-6">
                      <div>
                        <div className="mt-3 text-center sm:mt-5">
                          <h3 className="text-lg leading-6 font-medium text-gray-900">
                            Extracted Text
                          </h3>
                          <div className="mt-2">
                            <p className="text-sm text-gray-500 whitespace-pre-wrap">
                              {previewText}
                            </p>
                          </div>
                        </div>
                      </div>
                      <div className="mt-5 sm:mt-6">
                        <button
                          type="button"
                          className="inline-flex justify-center w-full rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:text-sm"
                          onClick={() => setPreviewText(null)}
                        >
                          Close
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Notes */}
            <div>
              <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                Additional Notes
              </label>
              <textarea
                id="notes"
                rows={3}
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                placeholder="Any additional information about the claim..."
              />
            </div>

            {/* Submit Button */}
            <div>
              <button
                type="submit"
                disabled={loading || processingFiles}
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
              >
                {loading ? 'Submitting...' : processingFiles ? 'Processing Files...' : 'Submit Claim'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}