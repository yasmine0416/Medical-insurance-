import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, Users, FileText, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { FamilyMember, Claim } from '../../types/database';

const CLAIMS_PER_PAGE = 5;

export default function PolicyholderDashboard() {
  const { profile } = useAuth();
  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([]);
  const [claims, setClaims] = useState<Claim[]>([]);
  const [totalClaims, setTotalClaims] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchDashboardData() {
      if (!profile) return;

      try {
        // Fetch family members
        const { data: familyMembersData, error: familyMembersError } = await supabase
          .from('family_members')
          .select('*')
          .eq('profile_id', profile.id)
          .order('created_at', { ascending: false });

        if (familyMembersError) throw familyMembersError;
        setFamilyMembers(familyMembersData);

        // Set up real-time subscription for claims
        const claimsSubscription = supabase
          .channel('claims_changes')
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'claims',
              filter: `family_member_id=in.(${familyMembersData.map(fm => fm.id).join(',')})`
            },
            () => {
              fetchClaims();
            }
          )
          .subscribe();

        // Initial claims fetch
        await fetchClaims();

        return () => {
          claimsSubscription.unsubscribe();
        };
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchDashboardData();
  }, [profile]);

  async function fetchClaims() {
    if (!profile) return;

    try {
      // Get total count
      const { count, error: countError } = await supabase
        .from('claims')
        .select('*', { count: 'exact', head: true })
        .in('family_member_id', familyMembers.map(fm => fm.id));

      if (countError) throw countError;
      setTotalClaims(count || 0);

      // Fetch paginated claims
      const { data: claimsData, error: claimsError } = await supabase
        .from('claims')
        .select(`
          *,
          family_members (
            *,
            profiles (*)
          )
        `)
        .in('family_member_id', familyMembers.map(fm => fm.id))
        .order('created_at', { ascending: false })
        .range((currentPage - 1) * CLAIMS_PER_PAGE, currentPage * CLAIMS_PER_PAGE - 1);

      if (claimsError) throw claimsError;
      setClaims(claimsData);
    } catch (error) {
      console.error('Error fetching claims:', error);
    }
  }

  useEffect(() => {
    fetchClaims();
  }, [currentPage, familyMembers]);

  if (loading) {
    return <div>Loading...</div>;
  }

  const totalPages = Math.ceil(totalClaims / CLAIMS_PER_PAGE);

  return (
    <div className="space-y-6">
      <div className="sm:flex sm:items-center sm:justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">Welcome, {profile?.full_name}</h1>
        <div className="mt-4 sm:mt-0">
          <Link
            to="/claims/new"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <PlusCircle className="h-5 w-5 mr-2" />
            New Claim
          </Link>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Users className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Family Members
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {familyMembers.length}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link
                to="/family-members"
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                View all
              </Link>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <FileText className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Claims
                  </dt>
                  <dd className="flex items-baseline">
                    <div className="text-2xl font-semibold text-gray-900">
                      {totalClaims}
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
          <div className="bg-gray-50 px-5 py-3">
            <div className="text-sm">
              <Link
                to="/claims"
                className="font-medium text-blue-600 hover:text-blue-500"
              >
                View all
              </Link>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h2 className="text-lg font-medium text-gray-900">Recent Claims</h2>
          <div className="mt-4">
            {claims.length > 0 ? (
              <div className="flow-root">
                <ul className="-my-5 divide-y divide-gray-200">
                  {claims.map((claim) => (
                    <li key={claim.id} className="py-5">
                      <div className="flex items-center space-x-4">
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {claim.provider_name}
                          </p>
                          <p className="text-sm text-gray-500">
                            Family Member: {claim.family_member_name}
                          </p>
                          <p className="text-sm text-gray-500">
                            Amount: DA{claim.amount}
                          </p>
                          <p className="text-sm text-gray-500">
                            Date: {new Date(claim.date).toLocaleDateString()}
                          </p>
                        </div>
                        <div>
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              claim.status === 'approved'
                                ? 'bg-green-100 text-green-800'
                                : claim.status === 'rejected'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {claim.status}
                          </span>
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="mt-4 flex items-center justify-between border-t border-gray-200 px-4 py-3 sm:px-6">
                    <div className="flex flex-1 justify-between sm:hidden">
                      <button
                        onClick={() => setCurrentPage(page => Math.max(1, page - 1))}
                        disabled={currentPage === 1}
                        className="relative inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                      >
                        Previous
                      </button>
                      <button
                        onClick={() => setCurrentPage(page => Math.min(totalPages, page + 1))}
                        disabled={currentPage === totalPages}
                        className="relative ml-3 inline-flex items-center rounded-md border border-gray-300 bg-white px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-50"
                      >
                        Next
                      </button>
                    </div>
                    <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between">
                      <div>
                        <p className="text-sm text-gray-700">
                          Showing <span className="font-medium">{(currentPage - 1) * CLAIMS_PER_PAGE + 1}</span> to{' '}
                          <span className="font-medium">
                            {Math.min(currentPage * CLAIMS_PER_PAGE, totalClaims)}
                          </span>{' '}
                          of <span className="font-medium">{totalClaims}</span> claims
                        </p>
                      </div>
                      <div>
                        <nav className="isolate inline-flex -space-x-px rounded-md shadow-sm" aria-label="Pagination">
                          <button
                            onClick={() => setCurrentPage(page => Math.max(1, page - 1))}
                            disabled={currentPage === 1}
                            className="relative inline-flex items-center rounded-l-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                          >
                            <span className="sr-only">Previous</span>
                            <ChevronLeft className="h-5 w-5" aria-hidden="true" />
                          </button>
                          <button
                            onClick={() => setCurrentPage(page => Math.min(totalPages, page + 1))}
                            disabled={currentPage === totalPages}
                            className="relative inline-flex items-center rounded-r-md px-2 py-2 text-gray-400 ring-1 ring-inset ring-gray-300 hover:bg-gray-50 focus:z-20 focus:outline-offset-0"
                          >
                            <span className="sr-only">Next</span>
                            <ChevronRight className="h-5 w-5" aria-hidden="true" />
                          </button>
                        </nav>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <p className="text-gray-500 text-sm">No recent claims</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}