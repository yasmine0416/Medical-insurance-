import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import { Claim } from '../../types/database';
import { FileText, Search, Calendar, Filter } from 'lucide-react';
import toast from 'react-hot-toast';
import { format, parseISO } from 'date-fns';

export default function Claims() {
  const { profile } = useAuth();
  const [claims, setClaims] = useState<Claim[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    search: '',
    serviceType: '',
    status: ''
  });

  useEffect(() => {
    async function fetchClaims() {
      if (!profile) return;

      let query = supabase
        .from('claims')
        .select(`
          *,
          family_members (
            *,
            profiles (*)
          )
        `)
        .eq('family_members.profile_id', profile.id)
        .order('created_at', { ascending: false });

      // Apply filters
      if (filters.startDate) {
        query = query.gte('date', filters.startDate);
      }
      if (filters.endDate) {
        query = query.lte('date', filters.endDate);
      }
      if (filters.search) {
        query = query.or(`provider_name.ilike.%${filters.search}%,service_type.ilike.%${filters.search}%,family_member_name.ilike.%${filters.search}%`);
      }
      if (filters.serviceType) {
        query = query.eq('service_type', filters.serviceType);
      }
      if (filters.status) {
        query = query.eq('status', filters.status);
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching claims:', error);
        toast.error('Failed to load claims');
        return;
      }

      setClaims(data || []);
      setLoading(false);
    }

    fetchClaims();
  }, [profile, filters]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-semibold text-gray-900">Claims History</h1>

      {/* Filters */}
      <div className="bg-white p-4 rounded-lg shadow">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Start Date</label>
            <input
              type="date"
              value={filters.startDate}
              onChange={(e) => setFilters(f => ({ ...f, startDate: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">End Date</label>
            <input
              type="date"
              value={filters.endDate}
              onChange={(e) => setFilters(f => ({ ...f, endDate: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Search</label>
            <div className="mt-1 relative rounded-md shadow-sm">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <Search className="h-4 w-4 text-gray-400" />
              </div>
              <input
                type="text"
                value={filters.search}
                onChange={(e) => setFilters(f => ({ ...f, search: e.target.value }))}
                placeholder="Provider, service, or member..."
                className="pl-10 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Service Type</label>
            <select
              value={filters.serviceType}
              onChange={(e) => setFilters(f => ({ ...f, serviceType: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            >
              <option value="">All Services</option>
              {Array.from(new Set(claims.map(c => c.service_type))).map(type => (
                <option key={type} value={type}>{type}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Status</label>
            <select
              value={filters.status}
              onChange={(e) => setFilters(f => ({ ...f, status: e.target.value }))}
              className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500 sm:text-sm"
            >
              <option value="">All Status</option>
              <option value="pending">Pending</option>
              <option value="approved">Approved</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </div>
      </div>

      {/* Claims List */}
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {claims.map((claim) => (
            <li key={claim.id}>
              <div className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <p className="text-lg font-medium text-gray-900">
                      {claim.provider_name}
                    </p>
                    <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Family Member:</span>{' '}
                          {claim.family_member_name}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Relationship:</span>{' '}
                          {claim.family_members?.relationship}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Service Type:</span>{' '}
                          {claim.service_type}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Amount:</span> DA{claim.amount}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Date:</span>{' '}
                          {format(parseISO(claim.date), 'MMM dd, yyyy')}
                        </p>
                        <p className="text-sm text-gray-500">
                          <span className="font-medium">Status:</span>{' '}
                          <span
                            className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                              claim.status === 'approved'
                                ? 'bg-green-100 text-green-800'
                                : claim.status === 'rejected'
                                ? 'bg-red-100 text-red-800'
                                : 'bg-yellow-100 text-yellow-800'
                            }`}
                          >
                            {claim.status}
                          </span>
                        </p>
                      </div>
                    </div>
                    {claim.rejection_reason && (
                      <div className="mt-2">
                        <p className="text-sm text-red-600">
                          <span className="font-medium">Rejection Reason:</span>{' '}
                          {claim.rejection_reason}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}