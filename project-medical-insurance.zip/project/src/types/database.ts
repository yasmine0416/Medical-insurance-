export type UserRole = 'policyholder' | 'insurer';
export type ClaimStatus = 'pending' | 'approved' | 'rejected';
export type RelationType = 'self' | 'spouse' | 'child' | 'parent';

export interface Profile {
  id: string;
  full_name: string;
  role: UserRole;
  city_id: string | null;
  created_at: string;
  updated_at: string;
}

export interface FamilyMember {
  id: string;
  profile_id: string;
  full_name: string;
  relationship: RelationType;
  date_of_birth: string;
  created_at: string;
  updated_at: string;
}

export interface Claim {
  id: string;
  family_member_id: string;
  insurer_id: string | null;
  date: string;
  amount: number;
  provider_name: string;
  service_type: string;
  status: ClaimStatus;
  documents: string[];
  notes: string | null;
  rejection_reason?: string | null;
  created_at: string;
  updated_at: string;
}

export interface City {
  id: string;
  name: string;
  created_at: string;
}