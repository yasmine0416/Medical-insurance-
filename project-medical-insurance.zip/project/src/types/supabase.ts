import { Database as DatabaseGenerated } from './database';

export type Database = DatabaseGenerated;

// This is a placeholder for the generated types.
// In a real project, you would generate these types from your Supabase schema
// using the Supabase CLI command: supabase gen types typescript --local > src/types/database.ts